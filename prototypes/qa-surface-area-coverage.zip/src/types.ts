export interface Diff {
  id: string;
  fileId: string;
}

export interface FileData {
  id: string;
  path: string;
  diffs: Diff[];
}

export interface QATask {
  id: string;
  description: string;
  coveredDiffIds: string[];
}

export interface TreeNode {
  name: string;
  path: string;
  type: 'file' | 'folder';
  children?: TreeNode[];
  fileId?: string;
}
