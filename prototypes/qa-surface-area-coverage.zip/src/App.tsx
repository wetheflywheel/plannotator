/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { ChevronRight, ChevronDown, CheckCircle2, Circle, FileCode, Folder, LayoutGrid } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Diff, FileData, QATask, TreeNode } from './types';
import { MOCK_FILES, MOCK_TASKS } from './mockData';

// --- Utils ---

const buildFileTree = (files: FileData[]): TreeNode => {
  const root: TreeNode = { name: 'root', path: '', type: 'folder', children: [] };

  files.forEach((file) => {
    const parts = file.path.split('/');
    let current = root;

    parts.forEach((part, index) => {
      const isLast = index === parts.length - 1;
      const path = parts.slice(0, index + 1).join('/');
      let child = current.children?.find((c) => c.name === part);

      if (!child) {
        child = {
          name: part,
          path,
          type: isLast ? 'file' : 'folder',
          children: isLast ? undefined : [],
          fileId: isLast ? file.id : undefined,
        };
        current.children?.push(child);
      }
      current = child;
    });
  });

  return root;
};

// --- Components ---

const Waffle = ({ total, covered, compressed = false }: { total: number; covered: number; compressed?: boolean }) => {
  const maxCells = compressed ? 12 : total;
  const cells = Array.from({ length: maxCells });

  return (
    <div className="flex gap-0.5 items-center">
      {cells.map((_, i) => {
        const isCovered = compressed 
          ? (i / maxCells) < (covered / total)
          : i < covered;
        
        return (
          <div
            key={i}
            className={`w-2 h-2 rounded-sm transition-colors duration-300 ${
              isCovered ? 'bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.4)]' : 'bg-zinc-800'
            }`}
          />
        );
      })}
    </div>
  );
};

interface FileTreeNodeProps {
  key?: string | number;
  node: TreeNode;
  depth: number;
  files: FileData[];
  coveredDiffIds: Set<string>;
  expandedFolders: Set<string>;
  toggleFolder: (path: string) => void;
}

const FileTreeNode = ({
  node,
  depth,
  files,
  coveredDiffIds,
  expandedFolders,
  toggleFolder,
}: FileTreeNodeProps) => {
  const isExpanded = expandedFolders.has(node.path);

  const stats = useMemo(() => {
    let total = 0;
    let covered = 0;

    const count = (n: TreeNode) => {
      if (n.type === 'file') {
        const file = files.find((f) => f.id === n.fileId);
        if (file) {
          total += file.diffs.length;
          covered += file.diffs.filter((d) => coveredDiffIds.has(d.id)).length;
        }
      } else {
        n.children?.forEach(count);
      }
    };

    count(node);
    return { total, covered, percent: total > 0 ? Math.round((covered / total) * 100) : 0 };
  }, [node, files, coveredDiffIds]);

  if (node.name === 'root') {
    return (
      <div className="space-y-0.5">
        {node.children?.map((child) => (
          <FileTreeNode
            key={child.path}
            node={child}
            depth={0}
            files={files}
            coveredDiffIds={coveredDiffIds}
            expandedFolders={expandedFolders}
            toggleFolder={toggleFolder}
          />
        ))}
      </div>
    );
  }

  return (
    <div className="select-none">
      <div
        className={`group flex items-center gap-2 py-1.5 px-2 cursor-pointer hover:bg-zinc-900/50 rounded transition-colors ${
          node.type === 'folder' ? 'font-medium text-zinc-300' : 'text-zinc-400'
        }`}
        style={{ paddingLeft: `${depth * 16 + 8}px` }}
        onClick={() => node.type === 'folder' && toggleFolder(node.path)}
      >
        <div className="w-4 h-4 flex items-center justify-center">
          {node.type === 'folder' ? (
            isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />
          ) : (
            <FileCode size={14} className="text-zinc-500" />
          )}
        </div>
        
        <span className="text-sm truncate flex-1">{node.name}</span>

        <div className="flex items-center gap-3 opacity-60 group-hover:opacity-100 transition-opacity">
          <Waffle total={stats.total} covered={stats.covered} compressed={node.type === 'folder'} />
          <span className={`text-[10px] font-mono w-8 text-right ${stats.percent === 100 ? 'text-emerald-500' : 'text-zinc-500'}`}>
            {stats.percent}%
          </span>
        </div>
      </div>

      <AnimatePresence initial={false}>
        {node.type === 'folder' && isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            {node.children?.map((child) => (
              <FileTreeNode
                key={child.path}
                node={child}
                depth={depth + 1}
                files={files}
                coveredDiffIds={coveredDiffIds}
                expandedFolders={expandedFolders}
                toggleFolder={toggleFolder}
              />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function App() {
  const [completedTaskIds, setCompletedTaskIds] = useState<Set<string>>(new Set());
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['src', 'src/components']));

  const tree = useMemo(() => buildFileTree(MOCK_FILES), []);

  const coveredDiffIds = useMemo(() => {
    const ids = new Set<string>();
    MOCK_TASKS.forEach((task) => {
      if (completedTaskIds.has(task.id)) {
        task.coveredDiffIds.forEach((id) => ids.add(id));
      }
    });
    return ids;
  }, [completedTaskIds]);

  const totalDiffs = useMemo(() => MOCK_FILES.reduce((acc, f) => acc + f.diffs.length, 0), []);
  const coveredCount = coveredDiffIds.size;
  const globalPercent = Math.round((coveredCount / totalDiffs) * 100);

  const toggleTask = (id: string) => {
    const next = new Set(completedTaskIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setCompletedTaskIds(next);
  };

  const toggleFolder = (path: string) => {
    const next = new Set(expandedFolders);
    if (next.has(path)) next.delete(path);
    else next.add(path);
    setExpandedFolders(next);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 font-sans selection:bg-emerald-500/30">
      {/* Header / Global Progress */}
      <header className="border-b border-zinc-800 bg-zinc-900/30 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500/10 rounded-lg">
                <LayoutGrid className="text-emerald-500" size={20} />
              </div>
              <div>
                <h1 className="text-lg font-semibold tracking-tight">QA Surface Area Coverage</h1>
                <p className="text-xs text-zinc-500 uppercase tracking-wider font-mono">PR #402 • Manual Verification Layer</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl font-mono font-light tracking-tighter">
                {coveredCount}<span className="text-zinc-600 mx-1">/</span>{totalDiffs}
              </div>
              <div className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest">Diffs Covered</div>
            </div>
          </div>
          
          <div className="relative h-1.5 w-full bg-zinc-800 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${globalPercent}%` }}
              className="absolute top-0 left-0 h-full bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.5)]"
            />
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">System Readiness</span>
            <span className="text-[10px] font-mono text-emerald-500 font-bold">{globalPercent}%</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: File Tree */}
        <section className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em]">Changed Files</h2>
            <div className="flex gap-4 text-[10px] font-mono text-zinc-600">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-sm bg-emerald-500" />
                <span>Covered</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-sm bg-zinc-800" />
                <span>Uncovered</span>
              </div>
            </div>
          </div>
          
          <div className="bg-zinc-900/20 border border-zinc-800/50 rounded-xl p-4 min-h-[400px]">
            <FileTreeNode
              node={tree}
              depth={0}
              files={MOCK_FILES}
              coveredDiffIds={coveredDiffIds}
              expandedFolders={expandedFolders}
              toggleFolder={toggleFolder}
            />
          </div>
        </section>

        {/* Right Column: QA Tasks */}
        <section className="lg:col-span-5 space-y-4">
          <h2 className="text-xs font-bold text-zinc-500 uppercase tracking-[0.2em] px-2">QA Verification Tasks</h2>
          
          <div className="space-y-2">
            {MOCK_TASKS.map((task) => {
              const isCompleted = completedTaskIds.has(task.id);
              return (
                <motion.div
                  key={task.id}
                  whileHover={{ x: 4 }}
                  onClick={() => toggleTask(task.id)}
                  className={`group flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                    isCompleted 
                      ? 'bg-emerald-500/5 border-emerald-500/20' 
                      : 'bg-zinc-900/40 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className={`mt-0.5 transition-colors ${isCompleted ? 'text-emerald-500' : 'text-zinc-600 group-hover:text-zinc-400'}`}>
                    {isCompleted ? <CheckCircle2 size={18} /> : <Circle size={18} />}
                  </div>
                  <div className="flex-1">
                    <p className={`text-sm leading-tight transition-colors ${isCompleted ? 'text-zinc-200' : 'text-zinc-400'}`}>
                      {task.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-500">
                        {task.coveredDiffIds.length} diffs
                      </span>
                      {isCompleted && (
                        <span className="text-[10px] font-mono text-emerald-500 font-bold uppercase tracking-tighter">
                          Verified
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          <div className="mt-8 p-6 rounded-2xl bg-zinc-900/40 border border-dashed border-zinc-800 flex flex-col items-center justify-center text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500">
              <LayoutGrid size={20} />
            </div>
            <div>
              <h3 className="text-sm font-medium text-zinc-300">Coverage authoring</h3>
              <p className="text-xs text-zinc-500 mt-1 max-w-[240px]">
                Mappings are defined manually to reflect implicit coverage from testing.
              </p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
