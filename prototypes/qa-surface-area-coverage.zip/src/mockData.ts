import { FileData, QATask } from './types';

export const MOCK_FILES: FileData[] = [
  {
    id: 'f1',
    path: 'src/components/Button.tsx',
    diffs: [
      { id: 'd1', fileId: 'f1' },
      { id: 'd2', fileId: 'f1' },
      { id: 'd3', fileId: 'f1' },
    ],
  },
  {
    id: 'f2',
    path: 'src/components/Input.tsx',
    diffs: [
      { id: 'd4', fileId: 'f2' },
      { id: 'd5', fileId: 'f2' },
    ],
  },
  {
    id: 'f3',
    path: 'src/services/api.ts',
    diffs: [
      { id: 'd6', fileId: 'f3' },
      { id: 'd7', fileId: 'f3' },
      { id: 'd8', fileId: 'f3' },
      { id: 'd9', fileId: 'f3' },
    ],
  },
  {
    id: 'f4',
    path: 'src/App.tsx',
    diffs: [
      { id: 'd10', fileId: 'f4' },
    ],
  },
  {
    id: 'f5',
    path: 'package.json',
    diffs: [
      { id: 'd11', fileId: 'f5' },
      { id: 'd12', fileId: 'f5' },
    ],
  },
];

export const MOCK_TASKS: QATask[] = [
  {
    id: 't1',
    description: 'Verify button click styles and states',
    coveredDiffIds: ['d1', 'd2'],
  },
  {
    id: 't2',
    description: 'Test input validation logic',
    coveredDiffIds: ['d4', 'd5'],
  },
  {
    id: 't3',
    description: 'End-to-end authentication flow',
    coveredDiffIds: ['d6', 'd7', 'd8', 'd10'],
  },
  {
    id: 't4',
    description: 'Check API error handling',
    coveredDiffIds: ['d8', 'd9'],
  },
  {
    id: 't5',
    description: 'Dependency update verification',
    coveredDiffIds: ['d11', 'd12'],
  },
  {
    id: 't6',
    description: 'Button accessibility audit',
    coveredDiffIds: ['d3'],
  },
];
